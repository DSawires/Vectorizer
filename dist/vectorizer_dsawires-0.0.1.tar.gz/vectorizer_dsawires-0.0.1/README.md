Vectorizer creates a vector triangulation of an image. 
Input: File Name, Number of random points, Weight of edges
Output: SVG file of vectorized image